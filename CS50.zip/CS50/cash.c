#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //get the amount of change owed from user
    int cents = get_int("Change owed : ");

    int coins = 0;

    //Calculate the number of coins needed
     //Quarters
    coins += cents / 25;
    cents %= 25;

    //dimes
    coins += cents / 10;
    cents %= 10;

    //Nickels
    coins += cents / 5;
    cents %= 5;

    //pennies
    coins += cents / 1;
    cents %= 1;

    // Print the result
    printf("%d\n", coins);

    return 0;
}
